app.post('/register', (req, res) => {
    const { username, password } = req.body;
  
    // Check the username
    const checkUsernameQuery = 'SELECT * FROM users WHERE username = ?';
    connection.query(checkUsernameQuery, [username], (error, results) => {
      if (error) {
        console.error('Terjadi kesalahan query: ', error);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
      } else {
        if (results.length > 0) {
          res.status(409).json({ error: 'Username sudah digunakan' });
        } else {
          // Adding new username
          const insertUserQuery = 'INSERT INTO users (username, password) VALUES (?, ?)';
          connection.query(insertUserQuery, [username, password], (error) => {
            if (error) {
              console.error('Terjadi kesalahan query: ', error);
              res.status(500).json({ error: 'Terjadi kesalahan pada server' });
            } else {
              res.json({ message: 'Registrasi berhasil' });
            }
          });
        }
      }
    });
  });
  